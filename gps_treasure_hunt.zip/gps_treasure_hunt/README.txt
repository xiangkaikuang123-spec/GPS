GPS Treasure Hunt — mobile browser prototype

WHAT IT DOES
- Uses your phone's GPS location.
- Spawns five virtual crystals around your starting location.
- Collects crystals when your GPS position is within 30 metres.
- Tracks crystals and XP for the current page session.
- Does not send location to a server or save it remotely.

HOW TO TRY IT ON A PHONE
1. Upload index.html to a static HTTPS host (for example, GitHub Pages or Netlify).
2. Open the HTTPS URL on your phone.
3. Allow location access and preferably test outdoors.
4. Walk toward a radar marker and tap “Scan Nearby” when you think you're close.

IMPORTANT
- Browser geolocation generally requires HTTPS (localhost is an exception).
- The radar is a simplified directional display, not a street map; markers are approximate.
- GPS accuracy can be poor indoors or between tall buildings. The 30 m collection radius is deliberately forgiving.
- Keep your phone secure and do not look at the screen while crossing roads.
- This is a prototype, not a published Android/iOS app. It can be wrapped as an app later.
